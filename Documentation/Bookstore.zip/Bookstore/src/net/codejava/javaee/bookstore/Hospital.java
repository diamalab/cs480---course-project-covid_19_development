package net.codejava.javaee.bookstore;
public class Hospital {
	/*
	 * Correspond to the user table
	 */
	private int ID;
	private String Name; 
	private int city;
	private int state;
	private String address;
	///////////Constructors//////////////////////
	
	public Hospital() {}
	
	public Hospital (int id) {
		this.ID=id;
	}
	
	public Hospital( int id ,String name,int city, int state, String address) {
		this(name,city,state,address);
		this.ID=id;
	}
	
	public Hospital( String name,int city, int state, String address) {
		this.Name=name;
		this.city=city;
		this.state=state;
		this.address=address;
	}
	//--------------------------------------------------

	////////////////////GET METHODS//////////////////
	public int getID() {
		return ID;
	}
	public String getName() {
		return Name;
	}
	public int getCity() {
		return city;
	}
	public int getState() {
		return state;
	}
	public String getAddress() {
		return address;
	}
	////////////////////////SET METHODS/////////////////
	

	public void setID(int id) {
		this.ID = id;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public void setState(int state) {
		this.state = state;
	}
	public void setCity(int city) {
		this.city = city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
