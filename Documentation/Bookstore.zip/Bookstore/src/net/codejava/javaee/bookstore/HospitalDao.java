package net.codejava.javaee.bookstore;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import java.util.ArrayList;
import java.util.List;





public class HospitalDao {
	
	private String jdbcURL;
    private String jdbcUsername;
    private String jdbcPassword;
    private Connection jdbcConnection;
     
    public HospitalDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
    	this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }
     
    protected void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            jdbcConnection = DriverManager.getConnection(
                                        jdbcURL, jdbcUsername, jdbcPassword);
        }
    }
     
    protected void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }
     
    public boolean insertHospital(Hospital hospital) throws SQLException {
        String sql = "INSERT INTO hospitals (Name, City, State,Address) VALUES (?, ?, ?,?)";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, hospital.getName());
        statement.setInt(2, hospital.getCity());
        statement.setInt(3, hospital.getState());
        statement.setString(4, hospital.getAddress());
         
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowInserted;
    }
     
    public List<Hospital> listAllHospitals() throws SQLException {
        List<Hospital> listHospital = new ArrayList<>();
         
        String sql = "SELECT * FROM hospitals";
         
        connect();
         
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            int id = resultSet.getInt("ID");
            String name = resultSet.getString("Name");
            int city = resultSet.getInt("City");
            int state = resultSet.getInt("State");
            String address = resultSet.getString("Address");
             
            Hospital hospital = new Hospital(id, name, city, state,address);
            listHospital.add(hospital);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
         
        return listHospital;
    }
     
    public boolean deleteHospital(Hospital hospital) throws SQLException {
        String sql = "DELETE FROM hospitals where ID = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, hospital.getID());
         
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowDeleted;     
    }
     
    public boolean updateHospital(Hospital hospital) throws SQLException {
        String sql = "UPDATE hospitals SET Name = ?, City = ?, State = ?,Address=?";
        sql += " WHERE ID = ?";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, hospital.getName());
        statement.setInt(2, hospital.getCity());
        statement.setInt(3, hospital.getState());
        statement.setString(4, hospital.getAddress());
        statement.setInt(5, hospital.getID());
         
        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowUpdated;     
    }
     
    public Hospital getHospital(int id) throws SQLException {
    	Hospital hospital = null;
        String sql = "SELECT * FROM hospitals WHERE ID = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
         
        ResultSet resultSet = statement.executeQuery();
         
        if (resultSet.next()) {
            String Name = resultSet.getString("name");
            int City = resultSet.getInt("city");
            int State = resultSet.getInt("state");
            String Address = resultSet.getString("address");
             
            hospital = new Hospital(id, Name, City, State,Address);
        }
         
        resultSet.close();
        statement.close();
         
        return hospital;
    }
		
}
