package net.codejava.javaee.bookstore;

import java.sql.Date;

public class Patient {
	protected int SSN;
	protected String Name; 
	protected String date;
	protected int city;
	protected int state;
	protected String address;
	///////////Constructors//////////////////////
	
	public Patient() {}
	//---------------------------------------------
	public Patient(int ssn) {
		this.SSN=ssn;
	}
	//-------------------------------------------
	public Patient(int ssn,String name,String date,int city,int state,String address) {
		this(name,date,city,state,address);
		this.SSN=ssn;
	}
	public Patient(String name,String date,int city,int state,String address) {
		this.Name=name;
		this.date=date;
		this.city=city;
		this.state=state;
		this.address=address;
	}
	
	////////////////////GET METHODS//////////////////
	public int getSSN() {
		return SSN;
	}
	public String getName() {
		return Name;
	}
	public String getDate() {
		return date;
	}
	public int getCity() {
		return city;
	}
	public int getState() {
		return state;
	}
	public String getAddress() {
		return address;
	}
	////////////////////////SET METHODS/////////////////
	

	public void setSSN(int ssn) {
		//this.SSN = Integer.parseInt(ssn);
		this.SSN=ssn;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public void setState(int state) {
		this.state = state;
	}
	public void setCity(int city) {
		this.city = city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	

}
