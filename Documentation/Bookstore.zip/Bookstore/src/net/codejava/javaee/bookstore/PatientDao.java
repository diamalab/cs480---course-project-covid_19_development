package net.codejava.javaee.bookstore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

public class PatientDao {
	private String jdbcURL;
    private String jdbcUsername;
    private String jdbcPassword;
    private Connection jdbcConnection;
     
    public PatientDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }
     
    protected void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            jdbcConnection = DriverManager.getConnection(
                                        jdbcURL, jdbcUsername, jdbcPassword);
        }
    }
     
    protected void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }
     
    public boolean insertPatient(Patient patient) throws SQLException {
        String sql = "INSERT INTO patients (SSN, Name, DOB,City,State,Address) VALUES (?, ?, ?,?,?,?)";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, patient.getSSN());
        statement.setString(2, patient.getName());
        statement.setString(3, patient.getDate());
        statement.setInt(4, patient.getCity());
        statement.setInt(5, patient.getState());
        statement.setString(6, patient.getAddress());
         
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowInserted;
    }
     
    public List<Patient> listAllPatient() throws SQLException {
        List<Patient> listPatients = new ArrayList<>();
         
        String sql = "SELECT * FROM patients";
         
        connect();
         
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
            int ssn = resultSet.getInt("ssn");
            String name = resultSet.getString("name");
            String date = resultSet.getString("dob");
            int city = resultSet.getInt("city");
            int state = resultSet.getInt("state");
            String address = resultSet.getString("address");
             
            Patient patient = new Patient(ssn, name, date, city,state,address);
            listPatients.add(patient);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
         
        return listPatients;
    }
     
    public boolean deletePatient(Patient patient) throws SQLException {
        String sql = "DELETE FROM patients where SSN = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, patient.getSSN());
         
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowDeleted;     
    }
     
    public boolean updatePatient(Patient patient) throws SQLException {
        String sql = "UPDATE patients SET SSN = ?, Name = ?,DOB=?, City = ?, State = ?, Address = ?";
        sql += " WHERE SSN = ?";
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, patient.getSSN());
        statement.setString(2, patient.getName());
        statement.setString(3, patient.getDate());
        statement.setInt(4, patient.getCity());
        statement.setInt(5, patient.getState());
        statement.setString(6, patient.getAddress());
         
        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        disconnect();
        return rowUpdated;     
    }
     
    public Patient getPatient(int id) throws SQLException {
    	Patient patient = null;
        String sql = "SELECT * FROM patients WHERE SSN = ?";
         
        connect();
         
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
         
        ResultSet resultSet = statement.executeQuery();
         
        if (resultSet.next()) {
            String name = resultSet.getString("name");
            String date = resultSet.getString("dob");
            int city=resultSet.getInt("city");
            int state=resultSet.getInt("state");
            String address = resultSet.getString("address");
             
            patient = new Patient(id, name, date, city,state,address);
        }
         
        resultSet.close();
        statement.close();
         
        return patient;
    }

}
