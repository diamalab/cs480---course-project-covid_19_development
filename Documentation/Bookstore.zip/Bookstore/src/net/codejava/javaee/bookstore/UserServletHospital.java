package net.codejava.javaee.bookstore;
 
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class UserServletHospital extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private HospitalDao hospitalDao;
 
    public void init() {
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
 
        hospitalDao = new HospitalDao(jdbcURL, jdbcUsername, jdbcPassword);
 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
 
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
                insertHospital(request, response);
                break;
            case "/delete":
                deleteHospital(request, response);
                break;
            case "/edit":
                showEditForm(request, response);
                break;
            case "/update":
                updateHospital(request, response);
                break;
            default:
                listHospital(request, response);
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
 
    private void listHospital(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Hospital> listHospital = hospitalDao.listAllHospitals();
        request.setAttribute("listhospital", listHospital);
        RequestDispatcher dispatcher = request.getRequestDispatcher("hospital.jsp");
        dispatcher.forward(request, response);
    }
    
 
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("hospitalForm.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Hospital existingHospital = hospitalDao.getHospital(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("hospitalForm.jsp");
        request.setAttribute("hospital", existingHospital);
        dispatcher.forward(request, response);
 
    }
 
    private void insertHospital(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        int city = Integer.parseInt(request.getParameter("city"));
        int state = Integer.parseInt(request.getParameter("state"));
        String address = request.getParameter("address");
 
        Hospital newHospital= new Hospital(name, city, state,address);
        hospitalDao.insertHospital(newHospital);
        response.sendRedirect("list");
    }
 
    private void updateHospital(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int city = Integer.parseInt(request.getParameter("city"));
        int state = Integer.parseInt(request.getParameter("state"));
        String address = request.getParameter("address");
 
        Hospital hospital = new Hospital(id, name, city, state,address);
        hospitalDao.updateHospital(hospital);
        response.sendRedirect("list");
    }
 
    private void deleteHospital(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
 
        Hospital hospital = new Hospital(id);
        hospitalDao.deleteHospital(hospital);
        response.sendRedirect("list");
 
    }
}
