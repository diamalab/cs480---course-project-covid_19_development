package net.codejava.javaee.bookstore;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.text.DateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class patientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private PatientDao patientDao;
 
    public void init() {
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
 
        patientDao = new PatientDao(jdbcURL, jdbcUsername, jdbcPassword);
 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();
 
        try {
            switch (action) {
            case "/new":
                showNewForm(request, response);
                break;
            case "/insert":
                insertPatient(request, response);
                break;
            case "/delete":
                deletePatient(request, response);
                break;
            case "/edit":
                showEditForm(request, response);
                break;
            case "/update":
                updatePatient(request, response);
                break;
            default:
                listPatient(request, response);
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
 
    private void listPatient(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Patient> listPatient = patientDao.listAllPatient();
        request.setAttribute("listPatient", listPatient);
        RequestDispatcher dispatcher = request.getRequestDispatcher("PatientList.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WebContent/patientForm.jsp");
        dispatcher.forward(request, response);
    }
 
    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int ssn = Integer.parseInt(request.getParameter("ssn"));
        Patient existingPatient = patientDao.getPatient(ssn);
        RequestDispatcher dispatcher = request.getRequestDispatcher("patientForm.jsp");
        request.setAttribute("patient", existingPatient);
        dispatcher.forward(request, response);
 
    }
 
    private void insertPatient(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
    	int ssn = Integer.parseInt(request.getParameter("ssn"));
        String name = request.getParameter("name");
        String date=request.getParameter("dob");
        int city = Integer.parseInt(request.getParameter("city"));
        int state = Integer.parseInt(request.getParameter("state"));
        String address = request.getParameter("address");
   
        Patient newPatient = new Patient(ssn, name, date,city,state,address);
        patientDao.insertPatient(newPatient);
        response.sendRedirect("list");
    }
 
    private void updatePatient(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int ssn = Integer.parseInt(request.getParameter("ssn"));
        String name = request.getParameter("name");
        String dob = request.getParameter("dob");
        int city = Integer.parseInt(request.getParameter("city"));
        int state = Integer.parseInt(request.getParameter("state"));
        String address = request.getParameter("address");
 
        Patient patient = new Patient(ssn, name, dob, city,state,address);
        patientDao.updatePatient(patient);
        response.sendRedirect("list");
    }
 
    private void deletePatient(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("ssn"));
 
        Patient patient = new Patient(id);
        patientDao.deletePatient(patient);
        response.sendRedirect("list");
 
    }
}