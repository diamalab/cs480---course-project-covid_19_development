package managment.model;

public class Patient {

	private int ssn;
	private String name; 
	private String dob;
	private int city;
	private int state;
	private String address;
	///////////Constructors//////////////////////
	
	public Patient(int sSN, String names, String date, int city, int state, String address) {
		super();
		ssn = sSN;
		name = names;
		this.dob = date;
		this.city = city;
		this.state = state;
		this.address = address;
	}
	
	
	
	public Patient(String names, String date, int city, int state, String address) {
		super();
		name = names;
		this.dob = date;
		this.city = city;
		this.state = state;
		this.address = address;
	}



	public int getSsn() {
		return ssn;
	}



	public void setSsn(int ssn) {
		this.ssn = ssn;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDob() {
		return dob;
	}



	public void setDob(String dob) {
		this.dob = dob;
	}



	public int getCity() {
		return city;
	}



	public void setCity(int city) {
		this.city = city;
	}



	public int getState() {
		return state;
	}



	public void setState(int state) {
		this.state = state;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	
	

}
